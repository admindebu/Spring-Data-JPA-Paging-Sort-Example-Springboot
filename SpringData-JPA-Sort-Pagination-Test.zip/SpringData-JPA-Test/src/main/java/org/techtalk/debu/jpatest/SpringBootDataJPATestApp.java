package org.techtalk.debu.jpatest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDataJPATestApp {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJPATestApp.class, args);
	}

}
