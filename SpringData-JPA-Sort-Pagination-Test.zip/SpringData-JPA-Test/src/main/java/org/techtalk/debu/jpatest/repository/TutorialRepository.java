package org.techtalk.debu.jpatest.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.techtalk.debu.jpatest.entity.Tutorial;

@Repository
public interface TutorialRepository extends JpaRepository<Tutorial, Long> {

	@Query("SELECT t FROM Tutorial t")
	List<Tutorial> findAll();

	@Query("SELECT t FROM Tutorial t")
	List<Tutorial> findAllSort(Sort sort);
	
	@Query("SELECT t FROM Tutorial t WHERE LOWER(t.title) LIKE LOWER(CONCAT('%', ?1,'%'))")
	List<Tutorial> findByTitleAndSort(String title, Sort sort);
	
	@Query("SELECT t FROM Tutorial t")
	Page<Tutorial> findAllWithPagination(Pageable pageable);


	
}
